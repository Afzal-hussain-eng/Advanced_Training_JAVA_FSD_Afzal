package com.afzal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreCloudserverEurekaRibbonResilience4jApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreCloudserverEurekaRibbonResilience4jApplication.class, args);
	}

}
