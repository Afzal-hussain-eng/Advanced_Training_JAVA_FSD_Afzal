package com.afzal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServiceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
