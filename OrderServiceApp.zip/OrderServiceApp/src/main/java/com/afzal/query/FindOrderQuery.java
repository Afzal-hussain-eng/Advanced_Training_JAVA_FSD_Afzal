package com.afzal.query;

import lombok.Value;

@Value
public class FindOrderQuery {

	private final String orderId;
}
