package com.mphasis.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mphasis.domain.Book;
import com.mphasis.repository.BookRepository;


@Service("bookService")
@Scope("singleton")
@Transactional
public class BookService implements IBookService {

	@Autowired
	@Qualifier("bookRepository")
	private BookRepository bookRepository;
	
	@Override
	public Book save(Book book) {
		return bookRepository.save(book);
	}

	@Override
	public Book update(Book book) {
		return bookRepository.save(book);
	}

	@Override
	public void delete(int id) {
		bookRepository.deleteById(id);
	}

	@Override
	@Transactional(readOnly = true)
	public Book getBookById(int id) {
		return bookRepository.findById(id).get();
	}

	@Override
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	@Override
	public List<Book> getByBookTitle(String title) {

		return bookRepository.findByBookTitle(title);
	}

	@Override
	public List<Book> getByBookPublisherLike(String publisher) {

		return bookRepository.findByBookPublisherLike(publisher);
	}

	@Override
	public List<Book> getByYear(Integer year) {

		return bookRepository.findByYear(year);
	}
}
