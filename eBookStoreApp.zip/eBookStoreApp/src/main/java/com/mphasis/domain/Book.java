package com.mphasis.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Book_Details")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "book_id")
	private Integer id;
	
	@Column(name = "book_title")
	private String bookTitle; 
	
	@Column(name = "book_publisher")
	private String bookPublisher;
	
	@Column(name = "book_isbn")
	private String bookIsbn;
	
	@Column(name = "book_number_of_pages")
	private Integer numberOfPages;
	
	@Column(name = "book_year")
	private Integer year;
}
