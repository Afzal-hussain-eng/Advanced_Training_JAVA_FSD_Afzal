package com.afzal.saga;


import org.axonframework.commandhandling.CommandCallback;
import org.axonframework.commandhandling.CommandMessage;
import org.axonframework.commandhandling.CommandResultMessage;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.modelling.saga.SagaEventHandler;
import org.axonframework.modelling.saga.StartSaga;
import org.axonframework.queryhandling.QueryGateway;
import org.axonframework.spring.stereotype.Saga;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.afzal.core.commands.ReserveProductCommand;
import com.afzal.core.events.OrderCreatedEvent;
import com.afzal.core.events.ProductReservedEvent;
import com.afzal.core.model.User;
import com.afzal.core.query.FetchUserPaymentDetailsQuery;

@Saga
public class OrderSaga {
	@Autowired
	private transient CommandGateway commandGateway;
	
	private transient QueryGateway queryGateway;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OrderSaga.class);
	
	
	@StartSaga
	@SagaEventHandler(associationProperty = "orderId")
	public void handle(OrderCreatedEvent orderCreatedEvent) {
		
		ReserveProductCommand reserveProductCommand = ReserveProductCommand.builder()
				.orderId(orderCreatedEvent.getOrderId())
				.quantity(orderCreatedEvent.getQuantity())
				.userId(orderCreatedEvent.getUserId())
				.productId(orderCreatedEvent.getProductId())
				.build();
		
		LOGGER.info("OrderCreatedEvent handled for orderId: " + reserveProductCommand.getOrderId() +
				" and productId: " + reserveProductCommand.getProductId());
		
		commandGateway.send(reserveProductCommand, new CommandCallback<ReserveProductCommand, Object>() {
		
			@Override
			public void onResult(CommandMessage<? extends ReserveProductCommand> commandMessage,
					CommandResultMessage<? extends Object> commandResultMessage) {

				if (commandResultMessage.isExceptional()) {
					// Start a compensating transaction
				}
			}
		});
	}
	
	@SagaEventHandler(associationProperty = "orderId")
	public void handle(ProductReservedEvent productReservedEvent) {
		//Process user payment here 
		LOGGER.info("ProductReservedEvent is called for productId: " + productReservedEvent.getOrderId() +
				" and orderId: " + productReservedEvent.getOrderId());
		
		
		FetchUserPaymentDetailsQuery fetchUserPaymentDetailsQuery= new FetchUserPaymentDetailsQuery(productReservedEvent.getUserId());
		
		User userPaymentDetails = null;
		
		try {
			userPaymentDetails= queryGateway.query(fetchUserPaymentDetailsQuery, 
					ResponseTypes.instanceOf(User.class)).join();
		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
			 LOGGER.error("Error fetching user payment details: {}", e.getMessage());
			//start compensating transactions
			return;
		}
		
		if(userPaymentDetails==null){
			//start compensating transactions
			 LOGGER.info("user payment details is null");
		return;
		
	}

		// Log the userPaymentDetails object to see its contents
		LOGGER.debug("User payment details: {}", userPaymentDetails);

		// Now, try to fetch the first name
		String firstName = userPaymentDetails.getFirstName();
		LOGGER.debug("First name: {}", firstName);

		if (firstName == null) {
		    LOGGER.warn("First name is null");
		}
	 LOGGER.info("sucessfully fetched user details from the user"+userPaymentDetails.getFirstName());
	}
	
	
}