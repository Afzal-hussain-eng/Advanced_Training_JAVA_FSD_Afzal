package com.afzal.query;

import org.axonframework.queryhandling.QueryHandler;
import org.springframework.stereotype.Component;

import com.afzal.core.data.OrderEntity;
import com.afzal.core.data.OrderRepository;
import com.afzal.core.model.OrderSummary;
import com.afzal.query.FindOrderQuery;

@Component
public class OrderQueriesHandler {

	private OrderRepository orderRepository;
	
	public OrderQueriesHandler(OrderRepository orderRepository) {
		this.orderRepository = orderRepository;
	}

	@QueryHandler
	public OrderSummary	findOrder(FindOrderQuery findOrderQuery) {
		
		OrderEntity orderEntity = orderRepository.findByOrderId(findOrderQuery.getOrderId());
		System.out.println(orderEntity + "==============================");
		return new OrderSummary(orderEntity.getOrderId(), orderEntity.getOrderStatus(), "");
	}
}

