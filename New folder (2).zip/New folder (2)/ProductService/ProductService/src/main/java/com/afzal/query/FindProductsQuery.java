package com.afzal.query;

public class FindProductsQuery {

}
