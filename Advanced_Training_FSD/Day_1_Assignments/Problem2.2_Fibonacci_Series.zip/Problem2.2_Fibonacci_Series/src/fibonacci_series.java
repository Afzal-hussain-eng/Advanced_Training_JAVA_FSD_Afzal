import java.util.Scanner;

class fibonacci_series {
	
	public static void main(String args[])  
	{    
	 int n1,n2,n3,i,count=13;    
	  
	 Scanner sc=new Scanner(System.in);
	 System.out.println("first number is:");
	 n1 = sc.nextInt();
	 
	 System.out.println("second number is:");
	 n2 = sc.nextInt();
	 
	 
	 System.out.println("Fibonacci series of the given numbers are: ");
	 System.out.print(n1+" "+n2);   
	 for(i=2;i<count;++i)    
	 {    
	  n3=n1+n2;
	 
	  
	  System.out.print(" "+n3);
	  n1=n2;    
	  n2=n3;    
	 }    
	
	  }

}

/*
first number is:
1
second number is:
3
Fibonacci series of the given numbers are: 
1 3 4 7 11 18 29 47 76 123 199 322 521
*/