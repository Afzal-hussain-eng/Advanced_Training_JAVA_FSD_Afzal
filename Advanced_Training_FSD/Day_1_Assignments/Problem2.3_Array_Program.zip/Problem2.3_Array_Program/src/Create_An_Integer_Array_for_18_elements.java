
public class Create_An_Integer_Array_for_18_elements {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0,avg;
		int[] array=new int[] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		  for (int i = 0; i < array.length; i++) {  
	           sum = sum + array[i];  
	        }  
		  System.out.println("Sum of all the elements of an array: " + sum);  
		  array[15]=sum;
	      System.out.println("Sum of the all element is stored in array[15] is :"+array[15]);
	     
	      //Calculating the average
		  avg=sum/array.length;
	        System.out.println("Average of the "+sum+" is "+avg);
		  array[16]=avg;
	      System.out.println("Average of the array is stored in array[16] is :"+array[16]);

		  //Calculating the average
	       // int avg = sum/18;
	        System.out.println("Average of the "+sum+" is "+avg);
	      
	        //calculating the smallest number in the array
	        //initialize with largest possible value
	        int smallest = Integer.MAX_VALUE;
	        //find smallest element of array
	        int index=0;
	        while(index<array.length) {
	            //check if smallest is greater than element
	            if(smallest>array[index]) {
	                //update smallest
	                smallest=array[index];
	            }
	            index++;
	        }
	        System.out.println("The smallest number in the array list is : "+ smallest);
	        array[17]=smallest;
	        System.out.println("smallest value is stored in array[17] is :"+array[17]);
	    }
	
     }
	/*
	 output
Sum of the all element is stored in array[15] is :58
Average of the 58 is 3
Average of the array is stored in array[16] is :3
Average of the 58 is 3
The smallest number in the array list is : 0
smallest value is stored in array[17] is :0

	 */

