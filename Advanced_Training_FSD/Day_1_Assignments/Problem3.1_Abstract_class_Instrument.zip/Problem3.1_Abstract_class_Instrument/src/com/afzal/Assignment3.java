package com.afzal;

import java.util.Random;

public class Assignment3 {

	public static void main(String[] args) {
		Instrument[] instruments = new Instrument[10];
		
		Random rand = new Random();
	    
	    for (int i = 0; i < 10; i++) {
	    	int randomNum = rand.nextInt((3 - 1) + 1) + 1;
	    	
	    	if (randomNum == 1)
	    		instruments[i] = new Piano();
	    	else if (randomNum == 2)
	    		instruments[i] = new Flute();
	    	else if (randomNum == 3)
	    		instruments[i] = new Guitar();
	    	
	    	instruments[i].play();
	    }
	    
	    for (int i = 0; i < 10; i++) {
	    	if (instruments[i] instanceof Piano) 
	    		System.out.println("Piano is stored at index " + i);
	    	else if (instruments[i] instanceof Flute) 
	    		System.out.println("Flute is stored at index " + i);
	    	else if (instruments[i] instanceof Guitar) 
	    		System.out.println("Guitar is stored at index " + i);
	    }

	}

}
/* 
out put
Flute is playing  toot toot toot toot
Piano is playing  tan tan tan tan
Flute is playing  toot toot toot toot
Piano is playing  tan tan tan tan
Piano is playing  tan tan tan tan
Flute is playing  toot toot toot toot
Guitar is playing  tin  tin  tin
Guitar is playing  tin  tin  tin
Piano is playing  tan tan tan tan
Guitar is playing  tin  tin  tin
Flute is stored at index 0
Piano is stored at index 1
Flute is stored at index 2
Piano is stored at index 3
Piano is stored at index 4
Flute is stored at index 5
Guitar is stored at index 6
Guitar is stored at index 7
Piano is stored at index 8
Guitar is stored at index 9
*/