import java.util.Scanner;

public class CheckPalindrome {

	public static void main(String args[])
	   {
	      String str, rev = "";
	      Scanner sc = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      str = sc.nextLine();
	 
	      int length = str.length();
	      System.out.println("string length is: "+str.length());
	      String strUpperCase = str.toUpperCase();

			System.out.println("Given String in Upper Case: " + strUpperCase);

			//readUserInputAndPrintInUpperCase();
	 
	      for ( int i = length - 1; i >= 0; i-- )
	         rev = rev + strUpperCase.charAt(i);
	 
	      if (strUpperCase.equals(rev))
	         System.out.println(strUpperCase+" is a palindrome");
	      else
	         System.out.println(strUpperCase+" is not a palindrome");
	 
	   }  }

/*
Output
Enter a string:
gadag
string length is: 5
Given String in Upper Case: GADAG
GADAG is a palindrome
*****
Enter a string:
abcd
string length is: 4
Given String in Upper Case: ABCD
ABCD is not a palindrome


*/