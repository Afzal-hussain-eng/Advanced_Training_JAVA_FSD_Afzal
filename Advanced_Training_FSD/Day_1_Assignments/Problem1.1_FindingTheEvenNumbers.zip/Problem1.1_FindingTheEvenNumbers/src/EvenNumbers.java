import java.util.Scanner;

public class EvenNumbers {

	  public static void main(String args[]) {

	  Scanner scan = new Scanner(System.in);
	  System.out.println("Enter the n value : ");
	  
	  int n = scan.nextInt();
System.out.println("The even numbers which lies in the number "+n+" are");
	  for (int i = 1; i <= n; i++) {

	   if (i % 2 == 0) {

	  System.out.print(i + " ");

	   }

	   }

	  }

}

/* 
output

Enter the n value : 
10
The even numbers which lies in the number 10 are
2 4 6 8 10 
*/