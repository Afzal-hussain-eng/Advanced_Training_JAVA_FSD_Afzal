package com.afzal;



public class ManipilateString {

		public static void main(String[] args) {
		
			
		
		String txt= "JAVA is Simple";
		
		System.out.println("Given string is : "+txt);
		System.out.println(" ");
		System.out.println("Converting it in to upper case is ");
		System.out.println(txt.toUpperCase()); //UpperCase
		
		System.out.println(" ");
		System.out.println("Converting it in to lower case is ");

		System.out.println(txt.toLowerCase()); //LowerCase
		
		System.out.println(" ");
		
		
		System.out.println("1st letter of each word");
		String[] words=txt.split("\\s");	//1st letter of each word
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		System.out.println(" ");
		
		System.out.println("Changing the order of the string ");
		String[] words1=txt.split("\\s"); // Change order 
		for(String w:words1){  
			System.out.println(w); 
		}
		
		System.out.println(" ");
		
		
		//String Builder reverse
		StringBuilder words2= new StringBuilder("Simple is JAVA");
		
		Object words21;
		System.out.println("String = " + words2.toString());
		StringBuilder reverseStr = words2.reverse();
		System.out.println("Reverse the String = " + reverseStr.toString());
		
		//Total Length
		System.out.println("length of string is  " + txt.length());
	}
	}

/*
output

Given string is : JAVA is Simple
 
Converting it in to upper case is 
JAVA IS SIMPLE
 
Converting it in to lower case is 
java is simple
 
1st letter of each word
J i S  
 
Changing the order of the string 
JAVA
is
Simple
 
String = Simple is JAVA
Reverse the String = AVAJ si elpmiS
length of string is  14
*/