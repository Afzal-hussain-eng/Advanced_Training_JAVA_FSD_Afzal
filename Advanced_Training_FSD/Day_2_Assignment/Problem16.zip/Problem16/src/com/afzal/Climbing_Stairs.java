package com.afzal;

import java.util.Scanner;

public class Climbing_Stairs {
	
	    public static int path(int n)
	    {
	        if(n==0)
	        {
	            return 1;
	        }
	        else if(n<0)
	        {
	            return 0;
	        }
	        int path1=path(n-1);
	        int path2=path(n-2);
	        
	        
	        int final_path=path1+path2;
	        return final_path;
	    }
	    public static void main(String[] args) throws Exception {
	        Scanner sc= new Scanner(System.in);
	        System.out.println("Enter the n steps to reach the top:-");
	        int nfs = sc.nextInt();
	        int result=path(nfs);
	        System.out.println("Number of distinct ways you can climb to the top are :-"+result);
	        
	    }
}

/*
 output
 Enter the n steps to reach the top:-
2
Number of distinct ways you can climb to the top are :-2
*/
