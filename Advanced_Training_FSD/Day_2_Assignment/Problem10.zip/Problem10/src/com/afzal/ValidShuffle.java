package com.afzal;

import java.util.Scanner;

public class ValidShuffle {
	public static void main(String[] args) {
		 //user input
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the first string");
		String first_string=sc.next();
		System.out.println("Enter the second string");

		String Second_string=sc.next();

System.out.println("Enter the expected result");
        String results = sc.next();
    
        validShuffle(first_string, Second_string, results);

    }

	//validating the strings 
    private static void validShuffle(String s1, String s2, String result) {
        
        String s3 = s1 + s2;
        StringBuffer s = new StringBuffer(s3);

        boolean flag = false;

        char[] ch = result.toCharArray();

        if (s.length() != result.length()) {
            flag = false;
        } else {

            for (int i = 0; i < ch.length; i++) {
                
                String temp = Character.toString(ch[i]);

                if (s3.contains(temp)) {

                    s = s.deleteCharAt(s.indexOf(temp));
                    s3 = new String(s);
                    flag = true;
                    
                } else {
                    flag = false;
                    break;
                }

            }

        }

        if (flag) {
            System.out.println("true : Third string is valid shuffle of first and second string.");
        } else {
            System.out.println("false : Third string is NOT a valid shuffle of first and second string.");
        }

    }
}

/*
 * output 
 * 1
Enter the first string
abc
Enter the second string
def
Enter the result
dabecf
true : Third string is valid shuffle of first and second string.

*2
Enter the first string
abdg
Enter the second string
cjsw
Enter the result
dcdjda
false : Third string is NOT a valid shuffle of first and second string.

*/
