package com.afzal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.afzal.domain.Book;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@Service
public class BookClientService {

	@Autowired
	private RestTemplate restTemplate;
	
//	@Retry(name = "book-service")
	@CircuitBreaker(name="book-service" ,fallbackMethod = "getDefaultBookById")
	public Book getBookById(int id) {
		Book book= restTemplate.getForObject("http://book-service/books/"+id, Book.class);
		return book;
	
	}
	
public Book getDefaultBookById(int id) {
	return new Book(id,"Fallback", "Afzal", "ISBN-23456", 676, 2029);
}
}
