package com.afzal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

import com.afzal.filters.ErrorFilter;
import com.afzal.filters.PostFilter;
import com.afzal.filters.PreFilter;
import com.afzal.filters.RouterFilter;
@EnableEurekaClient
@EnableZuulProxy
@SpringBootApplication
public class BookStoreCloudserverNetflixZuulEurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreCloudserverNetflixZuulEurekaApplication.class, args);
	}

	@Bean
	public PreFilter getPreFilter() {
		return new PreFilter();
	}
	
	@Bean
	public PostFilter getPostFilter() {
		return new PostFilter();
	}
	
	@Bean
	public ErrorFilter getErrorFilter() {
		return new ErrorFilter();
	}
	
	@Bean
	public RouterFilter getRouterFilter() {
		return new RouterFilter();
	}
}



