package com.afzal.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.afzal.domain.Book;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="book-service")
public interface BookServiceProxy {
	
	@Retry(name="book-service")
	@CircuitBreaker(name = "book-service",fallbackMethod = "fallBackMethodGetBookById")
	@GetMapping(value = "/books/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	Book getBookById(@PathVariable("id") int id);
	
	
	@Retry(name="book-service")
	@CircuitBreaker(name = "book-service",fallbackMethod = "fallBackMethodGetAllBooks")
	@GetMapping(value = "/books", produces = {MediaType.APPLICATION_JSON_VALUE})
	List<Book> getAllBooks();
	
	@PostMapping(value = "/books", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes ={MediaType.APPLICATION_JSON_VALUE} )
	void addBook(@RequestBody Book book);
	
	
	@PutMapping(value = "/books", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes ={MediaType.APPLICATION_JSON_VALUE} )
	Book updateBook(@RequestBody Book book);
	
	@DeleteMapping(value = "/books/{id}")
	void deleteBookById(@PathVariable("id") int id);
	
	
	
	default Book fallBackMethodGetBookById(int id, Throwable cause) {
		System.out.println("Exeption raised with message :==>"+cause.getMessage());
		return new Book(id,"Fallback", "Afzal", "ISBN-23456", 676, 2029);
		
	}
	
	default List<Book> fallBackMethodGetAllBooks(Throwable cause) {
		System.out.println("Exeption raised with message :==>"+cause.getMessage());
		return Arrays.asList();
		
	}
	
	
}
