package com.afzal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.afzal.domain.Book;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class BookClientService {

	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "getDefaultBookById")
	public Book getBookById(int id) {
		Book book= restTemplate.getForObject("http://book-service/books/"+id, Book.class);
		return book;
	
	}
	
public Book getDefaultBookById(int id) {
	return new Book(id,"Fallback", "Afzal", "ISBN-23456", 676, 2029);
}
}
