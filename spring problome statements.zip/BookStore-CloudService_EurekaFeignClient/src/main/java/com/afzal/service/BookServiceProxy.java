package com.afzal.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.afzal.domain.Book;

@FeignClient("book-service")
public interface BookServiceProxy {
	
	@GetMapping(value = "/books/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	Book getBookById(@PathVariable("id") int id);
	
	
	@GetMapping(value = "/books", produces = {MediaType.APPLICATION_JSON_VALUE})
	List<Book> getAllBooks();
	
	@PostMapping(value = "/books", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes ={MediaType.APPLICATION_JSON_VALUE} )
	Book addBook(@RequestBody Book book);
	
	
	@PutMapping(value = "/books", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes ={MediaType.APPLICATION_JSON_VALUE} )
	Book updateBook(@RequestBody Book book);
	
	@DeleteMapping(value = "/books/{id}")
	void deleteBookById(@PathVariable("id") int id);
	
	
}
