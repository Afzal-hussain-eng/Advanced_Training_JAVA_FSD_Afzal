package com.afzal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStore1Application {

	public static void main(String[] args) {
		SpringApplication.run(BookStore1Application.class, args);
	}

}
