package com.afzal.repo;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.afzal.domain.Book;
import java.util.List;



@Repository("bookRepository")
@Scope("singleton")
public interface BookRepository extends JpaRepository<Book, Integer> {

	List<Book> findByBookTitle(String bookTitle);
	List<Book> findByBookPublisher(String bookPublisher);
	List<Book> findByBookYear(Integer bookYear);
	
	
	
	
	
	
}
