package com.afzal.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RestController;

import com.afzal.service.BookService;

/**
 * 
 */
@RestController
@Scope("request")
public class BookController {
	

}