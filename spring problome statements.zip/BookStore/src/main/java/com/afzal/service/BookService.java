package com.afzal.service;

public interface BookService {

}
