package com.afzal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreCloudServerEurekaRibbonApplicationTests {

	@Test
	void contextLoads() {
	}

}
