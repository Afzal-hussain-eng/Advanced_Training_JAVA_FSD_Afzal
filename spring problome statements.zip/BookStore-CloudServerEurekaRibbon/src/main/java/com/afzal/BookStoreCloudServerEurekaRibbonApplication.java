package com.afzal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreCloudServerEurekaRibbonApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreCloudServerEurekaRibbonApplication.class, args);
	}

}
