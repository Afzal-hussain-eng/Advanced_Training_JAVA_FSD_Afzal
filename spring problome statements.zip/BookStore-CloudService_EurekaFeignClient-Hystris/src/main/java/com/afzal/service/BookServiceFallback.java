package com.afzal.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.afzal.domain.Book;

@Service
public class BookServiceFallback implements BookServiceProxy {

	@Override
	public Book getBookById(int id) {
		// TODO Auto-generated method stub
		return new Book(id,"Fallback", "Afzal", "ISBN-23456", 676, 2029);
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Book());
	}

	@Override
	public void  addBook(Book book) {
		// TODO Auto-generated method stub
		 System.out.println("Failed to add book. Fallback triggered.");
	}

	@Override
	public Book updateBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteBookById(int id) {
		// TODO Auto-generated method stub
		System.out.println("Delete by id is not working");
	}

}
