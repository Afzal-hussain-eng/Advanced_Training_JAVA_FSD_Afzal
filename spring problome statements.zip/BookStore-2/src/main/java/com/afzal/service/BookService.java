

package com.afzal.service;

import java.util.List;

import com.afzal.domain.Book;

public interface BookService {

	
	Book save(Book book);
	
	Book update(Book book);
	
	void delete(int id);
	
	Book getBookById(int id);
	
	List<Book> getAllBooks();
	
	List<Book> getAllBooksByPublisher(String bookPublisher);
	
	List<Book> gatAllBooksByYear(int year);
	
	List<Book> getAllBooksByTitle(String BookTitle);


}
