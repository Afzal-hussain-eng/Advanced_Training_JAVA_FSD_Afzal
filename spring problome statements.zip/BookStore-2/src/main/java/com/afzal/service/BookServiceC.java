package com.afzal.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.afzal.domain.Book;
import com.afzal.repo.BookRepository;

@Service("bookService")
@Scope("singleton")
@Transactional
public class BookServiceC implements BookService {
	
	@Autowired
	@Qualifier("bookRepository")
	private BookRepository bookRepo;
	
	
	@Override
	public Book save(Book book) {
		// TODO Auto-generated method stub
		return bookRepo.save(book);
	}

	@Override
	public Book update(Book book) {
		// TODO Auto-generated method stub
		return bookRepo.save(book);
	}

	@Override
	public void delete(int id) {
		bookRepo.deleteById(id);
	}

	@Override
	public Book getBookById(int id) {
		// TODO Auto-generated method stub
		return bookRepo.findById(id).get();
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return bookRepo.findAll();
	}

	@Override
	public List<Book> getAllBooksByPublisher(String bookPublisher) {
		// TODO Auto-generated method stub
		return bookRepo.findByBookPublisher(bookPublisher);
	}

	@Override
	public List<Book> gatAllBooksByYear(int year) {
		// TODO Auto-generated method stub
		return bookRepo.findByBookYear(year);
	}

	@Override
	public List<Book> getAllBooksByTitle(String BookTitle) {
		// TODO Auto-generated method stub
		return bookRepo.findByBookTitle(BookTitle);
	}

}
