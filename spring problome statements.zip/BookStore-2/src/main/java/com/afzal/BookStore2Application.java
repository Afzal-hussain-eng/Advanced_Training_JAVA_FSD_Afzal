package com.afzal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.afzal.domain.Book;
import com.afzal.repo.BookRepository;
@EnableEurekaClient
@SpringBootApplication
public class BookStore2Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(BookStore2Application.class, args);
	}

	@Autowired
	@Qualifier("bookRepository")
	private BookRepository bookrepo;
	
	@Override
	public void run(String... args) throws Exception {
		bookrepo.save(new Book(0,"Dummy Book 1", "Publisher A", "ISBN-123456", 200, 2020));
		bookrepo.save (new Book(0,"Dummy Book 2", "Publisher B", "ISBN-789012", 300, 2019));
		bookrepo.save (new Book(0,"Dummy Book 3", "Publisher C", "ISBN-789015", 400, 2021));
		bookrepo.save (new Book(0,"Transformer", "Afzal", "ISBN-23456", 234, 2024));

		List<Book> br= bookrepo.findAll();
		
		System.out.println("BookId"+"        BookTitle"+"               Publisher"+"                BookIsbn"+"           NoofPage"+"         year");
		
		
		for(Book b:br)
			System.out.println(b.getId()+"            "+b.getBookTitle()+"            "+b.getBookPublisher()+"              "+b.getBookIsbn()+"           "+b.getBookNumberOfPages()+"            "+b.getBookYear());
	
	
	System.out.println(bookrepo.findAll());
	}
}
