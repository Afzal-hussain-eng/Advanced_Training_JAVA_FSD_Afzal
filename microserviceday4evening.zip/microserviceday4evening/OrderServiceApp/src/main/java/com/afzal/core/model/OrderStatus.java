package com.afzal.core.model;

public enum OrderStatus {
	CREATED, APPROVED, REJECTED;
}
