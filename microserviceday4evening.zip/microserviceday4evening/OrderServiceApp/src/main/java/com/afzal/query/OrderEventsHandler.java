package com.afzal.query;

import org.axonframework.config.ProcessingGroup;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.afzal.core.data.OrderEntity;
import com.afzal.core.data.OrderRepository;
import com.afzal.core.events.OrderApprovedEvent;
import com.afzal.core.events.OrderCreatedEvent;
import com.afzal.core.events.OrderRejectedEvent;

@Component
@ProcessingGroup("order-group")
public class OrderEventsHandler {

	private final OrderRepository orderRepository;
	
	public OrderEventsHandler(OrderRepository orderRepository) {
		this.orderRepository = orderRepository;
	}
	
	@EventHandler
	public void on(OrderCreatedEvent event) throws Exception {
		
		OrderEntity orderEntity = new OrderEntity();
		BeanUtils.copyProperties(event, orderEntity);
		
		orderRepository.save(orderEntity);
	}
	
	@EventHandler
	public void on(OrderApprovedEvent orderApprovedvent) throws Exception{
		OrderEntity oderEntity= orderRepository.findByOrderId(orderApprovedvent.getOrderId());
	
		
		if (oderEntity==null) {
			//do something about it
			return;
		}
	oderEntity.setOrderStatus(orderApprovedvent.getOrderStatus());
	orderRepository.save(oderEntity);
	}
	
	@EventHandler
	public void on(OrderRejectedEvent event) throws Exception {
		
		OrderEntity orderEntity = orderRepository.findByOrderId(event.getOrderId());
		
		orderEntity.setOrderStatus(event.getOrderStatus());
		
		orderRepository.save(orderEntity);
	}
}
