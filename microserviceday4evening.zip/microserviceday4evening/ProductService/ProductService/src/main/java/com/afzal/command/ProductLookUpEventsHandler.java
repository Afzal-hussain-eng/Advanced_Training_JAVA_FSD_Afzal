package com.afzal.command;

import org.axonframework.config.ProcessingGroup;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import com.afzal.core.data.ProductLookUpEntity;
import com.afzal.core.data.ProductLookUpRepository;
import com.afzal.core.events.ProductCreatedEvent;

@Component
@ProcessingGroup("product-group")
public class ProductLookUpEventsHandler {

private final ProductLookUpRepository productLookUpRepository;
	
	public ProductLookUpEventsHandler(ProductLookUpRepository productLookUpRepository) {
		this.productLookUpRepository = productLookUpRepository;
	}
	
	@EventHandler
	public void on(ProductCreatedEvent event) {
		
		ProductLookUpEntity productLookUpEntity = new ProductLookUpEntity(
				event.getProductId(),event.getTitle()
				);
		
		
		productLookUpRepository.save(productLookUpEntity);
	}
}


