package com.afzal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreCloudserverEurekaFeignclientResilience4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
